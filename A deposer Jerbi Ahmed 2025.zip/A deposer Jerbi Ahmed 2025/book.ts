export interface Book {
    bookId: number;
    title: string;
    author: string;
    editor: string;
    category: string;
    publication_year: number;
    abstruct: string;
  }